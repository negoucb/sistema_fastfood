import { useState } from 'react'
import axios from 'axios'

export default function ProductForm() {
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')
  const [category, setCategory] = useState('')

  const submit = async () => {
    await axios.post('/api/products', { name, price: parseFloat(price), category }, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    })
    window.location.reload()
  }

  return (
    <div>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Nome" />
      <input value={price} onChange={e => setPrice(e.target.value)} placeholder="Preço" />
      <input value={category} onChange={e => setCategory(e.target.value)} placeholder="Categoria" />
      <button onClick={submit}>Cadastrar</button>
    </div>
  )
}
