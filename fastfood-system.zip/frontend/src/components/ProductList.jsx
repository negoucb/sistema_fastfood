import { useEffect, useState } from 'react'
import axios from 'axios'

export default function ProductList() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    axios.get('/api/products', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    }).then(res => setProducts(res.data))
  }, [])

  return (
    <ul>
      {products.map(p => <li key={p.id}>{p.name} - R$ {p.price}</li>)}
    </ul>
  )
}
