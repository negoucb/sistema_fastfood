const readline = require('readline')
const axios = require('axios')

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})

function ask(question) {
  return new Promise(resolve => rl.question(question, resolve))
}

async function main() {
  const email = await ask('Email: ')
  const password = await ask('Senha: ')

  const res = await axios.post('http://localhost:3001/api/auth/login', { email, password })
  const token = res.data.token

  const name = await ask('Nome do produto: ')
  const price = parseFloat(await ask('Preço: '))
  const category = await ask('Categoria: ')

  await axios.post('http://localhost:3001/api/products', { name, price, category }, {
    headers: { Authorization: `Bearer ${token}` }
  })

  console.log('Produto cadastrado com sucesso.')
  rl.close()
}

main()
